#ifndef __BufferStream_H__
#define __BufferStream_H__

#include <Arduino.h>

#include "ReadBufferStream.h"
#include "WriteBufferStream.h"

#endif // __BufferStream_H__
